from pathlib import Path
from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from app.core.config import TRAIN_DIR, STUDENT_TEST_DIR, EVALUATOR_DIR
from app.services.trip_service import discover_track_files, find_trip_file, analyze_bytes
from app.services.prediction_service import predict_trip

router = APIRouter(prefix="/api", tags=["Trips and evaluation"])
PARTITIONS = {"train": TRAIN_DIR, "student_test": STUDENT_TEST_DIR, "evaluator": EVALUATOR_DIR}


def _trip_list(partition: str):
    folder = PARTITIONS[partition]
    files = discover_track_files(folder)
    return [{"trip_id": p.stem, "filename": p.name, "partition": partition} for p in files]


@router.get("/trips")
def list_trips(partition: str = Query("train", pattern="^(train|student_test|evaluator)$")):
    folder = PARTITIONS[partition]
    return {"partition": partition, "count": len(discover_track_files(folder)), "trips": _trip_list(partition), "available": folder.exists()}


@router.get("/evaluator/trips")
def list_evaluator_trips():
    trips = _trip_list("evaluator")
    return {"partition": "evaluator", "count": len(trips), "trips": trips, "available": EVALUATOR_DIR.exists(), "message": None if trips else "No evaluator .track files found. Configure PATHSNAP_EVALUATOR_DIR or place evaluator files in the configured folder."}


@router.post("/trips/analyze")
async def analyze_uploaded_trip(file: UploadFile = File(...)):
    contents = await file.read()
    return analyze_bytes(contents, file.filename or "upload.track")


@router.post("/trips/{trip_id}/analyze")
def analyze_selected_trip(trip_id: str, partition: str = Query("train", pattern="^(train|student_test|evaluator)$")):
    path = find_trip_file(PARTITIONS[partition], trip_id)
    if path is None:
        raise HTTPException(status_code=404, detail=f"Trip {trip_id!r} was not found uniquely in partition {partition!r}.")
    return analyze_bytes(path.read_bytes(), path.name)


@router.post("/evaluator/trips/{trip_id}/predict")
def predict_evaluator_trip(trip_id: str):
    path = find_trip_file(EVALUATOR_DIR, trip_id)
    if path is None:
        raise HTTPException(status_code=404, detail=f"Evaluator trip {trip_id!r} was not found. Check PATHSNAP_EVALUATOR_DIR.")
    try:
        prediction = predict_trip(trip_id, path)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Prediction pipeline failed: {exc}") from exc
    if prediction is None:
        raise HTTPException(status_code=503, detail="Prediction pipeline is not connected. Set PATHSNAP_PREDICTOR_MODULE to a module implementing predict_trip(trip_id, track_path). No prediction or metrics have been fabricated.")
    return {
        "trip_id": trip_id,
        "status": "success",
        "predicted_route": prediction["predicted_route"],
        "coordinate_order": "longitude,latitude",
        "gps_observations": prediction.get("gps_observations", []),
        "route_segment_ids": prediction.get("route_segment_ids", []),
        "model_name": prediction.get("model_name"),
        "metrics": prediction.get("metrics"),
    }
