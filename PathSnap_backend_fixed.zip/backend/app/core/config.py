from pathlib import Path
import os

# Backend root is the directory containing this app/ folder.
BACKEND_ROOT = Path(__file__).resolve().parents[2]
# By default, put dataset partitions in ../data relative to backend root.
DATA_ROOT = Path(os.getenv("PATHSNAP_DATA_DIR", BACKEND_ROOT.parent / "data")).resolve()
TRAIN_DIR = Path(os.getenv("PATHSNAP_TRAIN_DIR", DATA_ROOT / "train")).resolve()
STUDENT_TEST_DIR = Path(os.getenv("PATHSNAP_STUDENT_TEST_DIR", DATA_ROOT / "student_test")).resolve()
EVALUATOR_DIR = Path(os.getenv("PATHSNAP_EVALUATOR_DIR", DATA_ROOT / "evaluator_test")).resolve()
