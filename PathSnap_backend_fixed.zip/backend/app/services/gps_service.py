import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["longitude", "latitude", "timestamp"]


def haversine_distance(lat1, lon1, lat2, lon2):
    """Vectorised geodesic distance in metres."""
    earth_radius = 6_371_000.0
    lat1 = np.radians(lat1)
    lat2 = np.radians(lat2)
    dlat = np.radians(lat2 - lat1)
    dlon = np.radians(lon2 - lon1)
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return earth_radius * 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))


def calculate_bearing(lat1, lon1, lat2, lon2):
    lat1, lat2 = np.radians(lat1), np.radians(lat2)
    dlon = np.radians(lon2 - lon1)
    y = np.sin(dlon) * np.cos(lat2)
    x = np.cos(lat1) * np.sin(lat2) - np.sin(lat1) * np.cos(lat2) * np.cos(dlon)
    return (np.degrees(np.arctan2(y, x)) + 360) % 360


def process_gps_trajectory(df: pd.DataFrame):
    """Validate GPS columns and calculate movement features without silently reordering rows."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")
    out = df[REQUIRED_COLUMNS].copy()
    input_rows = len(out)
    for col in REQUIRED_COLUMNS:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=REQUIRED_COLUMNS).reset_index(drop=True)
    dropped_rows = input_rows - len(out)
    if len(out) < 2:
        raise ValueError("At least two valid GPS observations are required.")
    if not out.longitude.between(-180, 180).all():
        raise ValueError("Invalid longitude outside [-180, 180].")
    if not out.latitude.between(-90, 90).all():
        raise ValueError("Invalid latitude outside [-90, 90].")

    dt = out.timestamp.diff().fillna(0)
    distance = haversine_distance(out.latitude.shift(1), out.longitude.shift(1), out.latitude, out.longitude)
    distance = pd.Series(distance, index=out.index).fillna(0)
    # Negative time deltas are retained and flagged; speed is only calculated for positive deltas.
    speed_ms = np.where(dt > 0, distance / dt.where(dt > 0, np.nan), 0.0)
    out["time_diff_s"] = dt
    out["dist_m"] = distance
    out["speed_ms"] = speed_ms
    out["speed_kmh"] = out.speed_ms * 3.6
    out["heading_deg"] = calculate_bearing(out.latitude.shift(1), out.longitude.shift(1), out.latitude, out.longitude)
    out["heading_deg"] = out.heading_deg.fillna(0)
    out["flag_speed_anomaly"] = out.speed_ms > 50
    out["flag_gap_gt_5s"] = dt > 5
    out["flag_extreme_gap"] = dt > 60
    out["flag_non_increasing_timestamp"] = (dt < 0) | ((dt == 0) & (out.index > 0))
    out.attrs["input_rows"] = input_rows
    out.attrs["dropped_invalid_rows"] = dropped_rows
    return out


def summarize_trajectory(processed: pd.DataFrame):
    duration = float(processed.timestamp.iloc[-1] - processed.timestamp.iloc[0])
    return {
        "observations": int(len(processed)),
        "input_observations": int(processed.attrs.get("input_rows", len(processed))),
        "dropped_invalid_observations": int(processed.attrs.get("dropped_invalid_rows", 0)),
        "total_distance_m": round(float(processed.dist_m.sum()), 2),
        "total_distance_km": round(float(processed.dist_m.sum()) / 1000, 3),
        "duration_seconds": round(duration, 2),
        "average_speed_kmh": round(float(processed.speed_kmh.mean()), 2),
        "maximum_speed_kmh": round(float(processed.speed_kmh.max()), 2),
        "speed_anomalies": int(processed.flag_speed_anomaly.sum()),
        "large_time_gaps": int(processed.flag_gap_gt_5s.sum()),
        "extreme_time_gaps": int(processed.flag_extreme_gap.sum()),
        "non_increasing_timestamps": int(processed.flag_non_increasing_timestamp.sum()),
    }
