from pathlib import Path
import io
import pandas as pd
from fastapi import HTTPException
from app.services.gps_service import process_gps_trajectory, summarize_trajectory


def discover_track_files(folder: Path):
    if not folder.exists() or not folder.is_dir():
        return []
    return sorted(folder.rglob("*.track"), key=lambda p: str(p).lower())


def read_track_bytes(contents: bytes, filename: str):
    name = (filename or "").lower()
    try:
        if name.endswith(".track"):
            df = pd.read_csv(io.BytesIO(contents), sep=r"\s+", header=None, names=["longitude", "latitude", "timestamp"], comment="#")
        elif name.endswith(".csv"):
            # Headered CSV is preferred; headerless three-column CSV is also accepted.
            df = pd.read_csv(io.BytesIO(contents))
            if not set(["longitude", "latitude", "timestamp"]).issubset(df.columns):
                df = pd.read_csv(io.BytesIO(contents), header=None, names=["longitude", "latitude", "timestamp"])
        else:
            raise HTTPException(status_code=400, detail="Only .track and .csv files are supported.")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not parse GPS file: {exc}") from exc
    return df


def analyze_bytes(contents: bytes, filename: str):
    df = read_track_bytes(contents, filename)
    try:
        processed = process_gps_trajectory(df)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {
        "filename": filename,
        "status": "success",
        "analysis": summarize_trajectory(processed),
        "trajectory": processed[["longitude", "latitude", "timestamp"]].to_dict(orient="records"),
        "coordinate_order": "longitude,latitude",
    }


def find_trip_file(folder: Path, trip_id: str):
    # Match only the stem, preventing arbitrary path traversal from trip_id.
    if not trip_id or Path(trip_id).name != trip_id:
        return None
    matches = [p for p in discover_track_files(folder) if p.stem == trip_id]
    return matches[0] if len(matches) == 1 else None
