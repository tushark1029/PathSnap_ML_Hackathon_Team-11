from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.trip_routes import router

app = FastAPI(
    title="PathSnap API",
    description="GPS trip access, trajectory analysis, and map-matching evaluation API.",
    version="1.1.0",
)
# Streamlit's Python requests run server-to-server; CORS is not required for that.
# Keep CORS permissive for browser-based local testing, without credentials.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"]
)
app.include_router(router)

@app.get("/")
def home():
    return {"project": "PathSnap", "status": "online", "api_version": app.version}

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "PathSnap API"}

@app.get("/api/models")
def get_models():
    # Deliberately do not return invented training metrics.
    return {"models": [], "message": "No model registry is configured. Connect the actual trained model artifacts and report measured metrics."}
