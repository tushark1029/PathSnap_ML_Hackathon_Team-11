# PathSnap FastAPI backend (patched)

## What this version provides

- `GET /` and `GET /health`
- `GET /api/trips?partition=train|student_test|evaluator` — list `.track` files from configured local folders
- `GET /api/evaluator/trips` — evaluator-only trip list
- `POST /api/trips/analyze` — backwards-compatible `.track`/`.csv` upload analysis
- `POST /api/trips/{trip_id}/analyze?partition=train` — analyze a selected local trip by ID
- `POST /api/evaluator/trips/{trip_id}/predict` — prediction endpoint contract for the frontend
- `GET /api/models` — returns no fabricated metrics

## Important limitation

The supplied `backend.zip` did not contain trained `.joblib` files, a road graph, or a runnable ML/HMM inference pipeline. The supplied dataset ZIP previously inspected also contained `train` and `student_test`, but no `evaluator_test` partition. Therefore this backend does **not** invent predictions or evaluator data. The evaluator listing will be empty until the reserved evaluator files are made available on the backend machine. The predict endpoint returns HTTP 503 until the real predictor is connected.

## Folder layout

Place the dataset alongside this backend folder:

```
project-root/
  backend/                 # this folder
  data/
    train/                 # .track files (subfolders supported)
    student_test/          # .track files (subfolders supported)
    evaluator_test/        # only if/when organisers provide it
```

You can override paths with environment variables:
- `PATHSNAP_DATA_DIR`
- `PATHSNAP_TRAIN_DIR`
- `PATHSNAP_STUDENT_TEST_DIR`
- `PATHSNAP_EVALUATOR_DIR`

## Install and run (Windows)

From this `backend` folder:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open `http://127.0.0.1:8000/docs`.

## Connect the real ML/HMM predictor

Create a Python module importable from this backend, exposing:

```python
def predict_trip(trip_id: str, track_path):
    # Run the team's actual preprocessing, feature extraction, model inference,
    # candidate/road sequence logic and HMM route reconstruction.
    return {
        "predicted_route": [[77.59, 12.97], [77.60, 12.98]], # [longitude, latitude]
        "gps_observations": [],
        "route_segment_ids": [],
        "model_name": "actual model name",
        "metrics": None, # or measured metrics only when ground truth is available
    }
```

Set `PATHSNAP_PREDICTOR_MODULE` to that module's import path before starting Uvicorn. Do not calculate accuracy for an evaluator trip unless its reference route/labels are legitimately available under the evaluation rules.

## Frontend response contract

`GET /api/evaluator/trips`:

```json
{"partition":"evaluator","count":0,"trips":[],"available":false,"message":"..."}
```

`POST /api/evaluator/trips/{trip_id}/predict` on successful inference:

```json
{
  "trip_id": "eval_001",
  "status": "success",
  "predicted_route": [[77.59, 12.97], [77.60, 12.98]],
  "coordinate_order": "longitude,latitude",
  "gps_observations": [],
  "route_segment_ids": [],
  "model_name": "...",
  "metrics": null
}
```

HTTP 404 means the trip ID/file is unavailable. HTTP 503 means the real predictor is not connected. HTTP 500 means the predictor raised an error.
